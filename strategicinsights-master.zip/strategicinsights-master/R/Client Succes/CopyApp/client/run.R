#!/usr/bin/Rscript

print("HELLO")
library(shiny)
library(methods)


runApp(".", 6020)


